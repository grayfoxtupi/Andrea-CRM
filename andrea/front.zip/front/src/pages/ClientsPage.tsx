function ClientsPage() {

    return(
        <div>
            Clients Page
        </div>
    )
}

export default ClientsPage