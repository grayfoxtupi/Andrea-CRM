function CalendarPage() {

    return(
        <div>
            Calendar Page
        </div>
    )
}

export default CalendarPage