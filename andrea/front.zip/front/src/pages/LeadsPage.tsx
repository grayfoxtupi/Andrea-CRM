function LeadsPage() {

    return(
        <div>
            Leads Page
        </div>
    )
}

export default LeadsPage