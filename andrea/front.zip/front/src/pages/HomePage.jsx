function HomePage() {

    return(
        <div>
            Home Page
        </div>
    )
}

export default HomePage