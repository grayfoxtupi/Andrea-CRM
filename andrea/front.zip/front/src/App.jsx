import { Routes, Route, Navigate, useLocation} from 'react-router-dom'
import CalendarPage from './pages/CalendarPage'
import ClientsPage from './pages/ClientsPage'
import LeadsPage from './pages/LeadsPage'
import LoginPage from './pages/LoginPage'
import HomePage from './pages/HomePage'
import LeadsTest from './tests/LeadsTests'

function App() {
  const location = useLocation()

  return(
    <div>
      <Routes key={location.pathname}>
        <Route path='/' element={< LeadsTest />} />
        <Route path='/login' element={< LoginPage />} />
        <Route path='/leads' element={< LeadsPage />} />
        <Route path='/clients' element={< ClientsPage />} />
        <Route path='/calendar' element={< CalendarPage />} />
      </Routes>
    </div>
  )

}

export default App