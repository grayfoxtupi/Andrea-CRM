import { create } from 'zustand'
import api from '../config/axiosInstance.js'

const leadsStore = create((get, set) => {
  
    return {
        leadsList: null,
        currentLead: null,
        isSettingLead: false,

        getLeads: async () => {
            const response = await api.get('/api/leads');
            return response.data;
        },

        getLeadById: async (leadId) => {
            const response = await api.get(`/api/leads/${leadId}`);
            return response.data;
        },

        createLead: async (leadTaskData) => {
            const response = await api.post('/api/lead-tasks', leadTaskData);
            return response.data;
        }
    };

});

export default leadsStore
