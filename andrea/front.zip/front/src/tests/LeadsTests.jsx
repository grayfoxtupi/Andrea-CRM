import React, { useEffect, useState } from 'react';
import leadsStore from '../hooks/useLeadsStore.js'

function LeadsTest() {
  const {
    getLeads,
    getLeadById,
    createLead
  } = leadsStore();

  const [leads, setLeads] = useState([]);
  const [leadDetails, setLeadDetails] = useState(null);
  const [newLead, setNewLead] = useState(null);

  // Testar pegar todos os leads
  const handleFetchLeads = async () => {
    const data = await getLeads();
    setLeads(data);
    console.log("LEADS:", data);
  };

  // Testar pegar um lead por ID
  const handleFetchLeadById = async () => {
    const data = await getLeadById(1); // use um ID válido
    setLeadDetails(data);
    console.log("LEAD BY ID:", data);
  };

  // Testar criar um novo lead
  const handleCreateLead = async () => {
    const payload = {
      contact: "John Doe",
      description: "Agendamento para demonstração",
      dueDate: "2025-07-01",
      lead: {
        leadId: 1
      }
    };

    const data = await createLead(payload);
    setNewLead(data);
    console.log("NEW LEAD CREATED:", data);
  };

  return (
    <div>
      <h1>Leads API Test</h1>

      <button onClick={handleFetchLeads}>Buscar todos os leads</button>
      <button onClick={handleFetchLeadById}>Buscar lead por ID</button>
      <button onClick={handleCreateLead}>Criar novo lead</button>

      <div>
        <h2>Leads:</h2>
        <pre>{JSON.stringify(leads, null, 2)}</pre>

        <h2>Lead por ID:</h2>
        <pre>{JSON.stringify(leadDetails, null, 2)}</pre>

        <h2>Novo lead criado:</h2>
        <pre>{JSON.stringify(newLead, null, 2)}</pre>
      </div>
    </div>
  );
}

export default LeadsTest;
